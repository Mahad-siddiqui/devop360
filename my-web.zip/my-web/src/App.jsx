import React from 'react';
import { ConfigProvider } from 'antd';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import EnergySolutions from './components/EnergySolutions.jsx';
import Platform from './components/Platform.jsx';
import About from './components/About.jsx';
import ContactForm from './components/ContactForm.jsx';
import Footer from './components/Footer.jsx';

function App() {
  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: '#14b8a6',
          colorBgContainer: '#1a1a1a',
          colorBgElevated: '#2a2a2a',
          colorText: '#ffffff',
          colorTextSecondary: '#a0a0a0',
          colorBorder: 'rgba(255, 255, 255, 0.2)',
          borderRadius: 8,
          fontFamily: 'Inter, system-ui, sans-serif',
        },
        components: {
          Input: {
            colorBgContainer: 'rgba(64, 64, 64, 0.5)',
            colorBorder: 'rgba(255, 255, 255, 0.2)',
            colorText: '#ffffff',
          },
          Select: {
            colorBgContainer: 'rgba(64, 64, 64, 0.5)',
            colorBorder: 'rgba(255, 255, 255, 0.2)',
            colorText: '#ffffff',
          },
          Button: {
            primaryShadow: 'none',
          },
        },
      }}
    >
      <div className="App">
        <Header />
        <main>
          <Hero />
          <EnergySolutions />
          <Platform />
          <About />
          <ContactForm />
        </main>
        <Footer />
      </div>
    </ConfigProvider>
  );
}

export default App;